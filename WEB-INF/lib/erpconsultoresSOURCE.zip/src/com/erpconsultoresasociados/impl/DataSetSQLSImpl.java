/*
 * XML Type:  DataSetSQLS
 * Namespace: http://www.erpconsultoresasociados.com/
 * Java type: com.erpconsultoresasociados.DataSetSQLS
 *
 * Automatically generated - do not modify.
 */
package com.erpconsultoresasociados.impl;
/**
 * An XML DataSetSQLS(@http://www.erpconsultoresasociados.com/).
 *
 * This is a complex type.
 */
public class DataSetSQLSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements com.erpconsultoresasociados.DataSetSQLS
{
    private static final long serialVersionUID = 1L;
    
    public DataSetSQLSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INITIALLOADRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.erpconsultoresasociados.com/", "InitialLoadResponse");
    private static final javax.xml.namespace.QName ERROR$2 = 
        new javax.xml.namespace.QName("http://www.erpconsultoresasociados.com/", "error");
    
    
    /**
     * Gets array of all "InitialLoadResponse" elements
     */
    public com.erpconsultoresasociados.InitialLoadResponse[] getInitialLoadResponseArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(INITIALLOADRESPONSE$0, targetList);
            com.erpconsultoresasociados.InitialLoadResponse[] result = new com.erpconsultoresasociados.InitialLoadResponse[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "InitialLoadResponse" element
     */
    public com.erpconsultoresasociados.InitialLoadResponse getInitialLoadResponseArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            com.erpconsultoresasociados.InitialLoadResponse target = null;
            target = (com.erpconsultoresasociados.InitialLoadResponse)get_store().find_element_user(INITIALLOADRESPONSE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "InitialLoadResponse" element
     */
    public int sizeOfInitialLoadResponseArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INITIALLOADRESPONSE$0);
        }
    }
    
    /**
     * Sets array of all "InitialLoadResponse" element  WARNING: This method is not atomicaly synchronized.
     */
    public void setInitialLoadResponseArray(com.erpconsultoresasociados.InitialLoadResponse[] initialLoadResponseArray)
    {
        check_orphaned();
        arraySetterHelper(initialLoadResponseArray, INITIALLOADRESPONSE$0);
    }
    
    /**
     * Sets ith "InitialLoadResponse" element
     */
    public void setInitialLoadResponseArray(int i, com.erpconsultoresasociados.InitialLoadResponse initialLoadResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            com.erpconsultoresasociados.InitialLoadResponse target = null;
            target = (com.erpconsultoresasociados.InitialLoadResponse)get_store().find_element_user(INITIALLOADRESPONSE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(initialLoadResponse);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "InitialLoadResponse" element
     */
    public com.erpconsultoresasociados.InitialLoadResponse insertNewInitialLoadResponse(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            com.erpconsultoresasociados.InitialLoadResponse target = null;
            target = (com.erpconsultoresasociados.InitialLoadResponse)get_store().insert_element_user(INITIALLOADRESPONSE$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "InitialLoadResponse" element
     */
    public com.erpconsultoresasociados.InitialLoadResponse addNewInitialLoadResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            com.erpconsultoresasociados.InitialLoadResponse target = null;
            target = (com.erpconsultoresasociados.InitialLoadResponse)get_store().add_element_user(INITIALLOADRESPONSE$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "InitialLoadResponse" element
     */
    public void removeInitialLoadResponse(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INITIALLOADRESPONSE$0, i);
        }
    }
    
    /**
     * Gets the "error" element
     */
    public java.lang.String getError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERROR$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "error" element
     */
    public org.apache.xmlbeans.XmlString xgetError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERROR$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "error" element
     */
    public void setError(java.lang.String error)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERROR$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ERROR$2);
            }
            target.setStringValue(error);
        }
    }
    
    /**
     * Sets (as xml) the "error" element
     */
    public void xsetError(org.apache.xmlbeans.XmlString error)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERROR$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ERROR$2);
            }
            target.set(error);
        }
    }
}
