/*
 * An XML document type.
 * Localname: InitialLoadResponse
 * Namespace: http://www.erpconsultoresasociados.com/
 * Java type: com.erpconsultoresasociados.InitialLoadResponseDocument
 *
 * Automatically generated - do not modify.
 */
package com.erpconsultoresasociados.impl;
/**
 * A document containing one InitialLoadResponse(@http://www.erpconsultoresasociados.com/) element.
 *
 * This is a complex type.
 */
public class InitialLoadResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements com.erpconsultoresasociados.InitialLoadResponseDocument
{
    private static final long serialVersionUID = 1L;
    
    public InitialLoadResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INITIALLOADRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.erpconsultoresasociados.com/", "InitialLoadResponse");
    
    
    /**
     * Gets the "InitialLoadResponse" element
     */
    public com.erpconsultoresasociados.DataSetSQLS getInitialLoadResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            com.erpconsultoresasociados.DataSetSQLS target = null;
            target = (com.erpconsultoresasociados.DataSetSQLS)get_store().find_element_user(INITIALLOADRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "InitialLoadResponse" element
     */
    public void setInitialLoadResponse(com.erpconsultoresasociados.DataSetSQLS initialLoadResponse)
    {
        generatedSetterHelperImpl(initialLoadResponse, INITIALLOADRESPONSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "InitialLoadResponse" element
     */
    public com.erpconsultoresasociados.DataSetSQLS addNewInitialLoadResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            com.erpconsultoresasociados.DataSetSQLS target = null;
            target = (com.erpconsultoresasociados.DataSetSQLS)get_store().add_element_user(INITIALLOADRESPONSE$0);
            return target;
        }
    }
}
