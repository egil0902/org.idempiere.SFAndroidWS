/*
 * An XML document type.
 * Localname: InitialLoad
 * Namespace: http://www.erpconsultoresasociados.com/
 * Java type: com.erpconsultoresasociados.InitialLoadDocument
 *
 * Automatically generated - do not modify.
 */
package com.erpconsultoresasociados.impl;
/**
 * A document containing one InitialLoad(@http://www.erpconsultoresasociados.com/) element.
 *
 * This is a complex type.
 */
public class InitialLoadDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements com.erpconsultoresasociados.InitialLoadDocument
{
    private static final long serialVersionUID = 1L;
    
    public InitialLoadDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INITIALLOAD$0 = 
        new javax.xml.namespace.QName("http://www.erpconsultoresasociados.com/", "InitialLoad");
    
    
    /**
     * Gets the "InitialLoad" element
     */
    public com.erpconsultoresasociados.InitialLoad getInitialLoad()
    {
        synchronized (monitor())
        {
            check_orphaned();
            com.erpconsultoresasociados.InitialLoad target = null;
            target = (com.erpconsultoresasociados.InitialLoad)get_store().find_element_user(INITIALLOAD$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "InitialLoad" element
     */
    public void setInitialLoad(com.erpconsultoresasociados.InitialLoad initialLoad)
    {
        generatedSetterHelperImpl(initialLoad, INITIALLOAD$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "InitialLoad" element
     */
    public com.erpconsultoresasociados.InitialLoad addNewInitialLoad()
    {
        synchronized (monitor())
        {
            check_orphaned();
            com.erpconsultoresasociados.InitialLoad target = null;
            target = (com.erpconsultoresasociados.InitialLoad)get_store().add_element_user(INITIALLOAD$0);
            return target;
        }
    }
}
